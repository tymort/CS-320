package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import contact.ContactService;

class ContactServiceTest{
		//Test create contact with no ID
		@Test
		void testContactServiceCreate() {
			ContactService.createContact("John", "Doe", "1234567891", "123 Road");
			//Check to validate object values match expected values
			assertTrue(ContactService.contacts.get(0).getContactID().equals("1000000001"));
			assertTrue(ContactService.contacts.get(0).getFirstName().equals("John"));
			assertTrue(ContactService.contacts.get(0).getLastName().equals("Doe"));
			assertTrue(ContactService.contacts.get(0).getPhone().equals("1234567891"));
			assertTrue(ContactService.contacts.get(0).getAddress().equals("123 Road"));
		}
		
		//Test create contact with ID
		@Test
		void testContactServiceCreateManual() {
			ContactService.createContact("1234567891", "John", "Doe", "1234567891", "123 Road");
			//Check contacts to find index of created contact
			int contactIndex = 0;
			for(int i = 0; i < ContactService.contacts.size(); i++) {
				//If contact ID matches
				if(ContactService.contacts.get(i).getContactID().equals("1234567891")) {
					//Update index value
					contactIndex = i;
				}
			}
			//Check to validate object values match expected values at index value
			assertTrue(ContactService.contacts.get(contactIndex).getContactID().equals("1234567891"));
			assertTrue(ContactService.contacts.get(contactIndex).getFirstName().equals("John"));
			assertTrue(ContactService.contacts.get(contactIndex).getLastName().equals("Doe"));
			assertTrue(ContactService.contacts.get(contactIndex).getPhone().equals("1234567891"));
			assertTrue(ContactService.contacts.get(contactIndex).getAddress().equals("123 Road"));
		}
		
		//Test contact deletion
		@Test
		void testContactServiceDelete() {
			//Declare and initialize flag variable
			boolean contactPresent = false;
			//Create contact
			ContactService.createContact("John", "Doe", "1234567891", "123 Road");
			//Delete contact
			ContactService.deleteContact("1000000002");
			//Check through contacts
			for(int i = 0; i < ContactService.contacts.size(); i++) {
				//If contact matches deleted contact
				if(ContactService.contacts.get(i).getContactID().equals("1000000002")) {
					//Update flag variable
					contactPresent = true;
				}
			}
			//Check to validate flag is false
			assertFalse(contactPresent);
		}
		
			//Test first name update
			@Test 
			void testContactServiceUpdateFirstName() {
				int contactIndex = 0;
				//Create a contact
				ContactService.createContact("1","John", "Doe", "1234567891", "123 Road");
				//Find contact index
				for(int i = 0; i < ContactService.contacts.size(); i++) {
					if(ContactService.contacts.get(i).getContactID().equals("1")) {
						contactIndex = i;
					}
				}
				//Update name at index
				ContactService.updateFirstName("1", "Jane");
				//Check to validate object values match expected values
				assertTrue(ContactService.contacts.get(contactIndex).getFirstName().equals("Jane"));
			}
			
			//Test last name update
			@Test 
			void testContactServiceUpdateLastName() {
				int contactIndex = 0;
				//Create a contact
				ContactService.createContact("2","John", "Doe", "1234567891", "123 Road");
				//Find contact index
				for(int i = 0; i < ContactService.contacts.size(); i++) {
					if(ContactService.contacts.get(i).getContactID().equals("2")) {
						contactIndex = i;
					}
				}
				//Update name at index
				ContactService.updateLastName("2", "Dough");
				//Check to validate object values match expected values
				assertTrue(ContactService.contacts.get(contactIndex).getLastName().equals("Dough"));
			}
			
			//Test phone number update
			@Test 
			void testContactServiceUpdatePhone() {
				int contactIndex = 0;
				//Create a contact
				ContactService.createContact("3","John", "Doe", "1234567891", "123 Road");
				//Find contact index
				for(int i = 0; i < ContactService.contacts.size(); i++) {
					if(ContactService.contacts.get(i).getContactID().equals("3")) {
						contactIndex = i;
					}
				}
				//Update phone at index
				ContactService.updatePhone("3", "1011011111");
				//Check to validate object values match expected values
				assertTrue(ContactService.contacts.get(contactIndex).getPhone().equals("1011011111"));
			}
			
			//Test address update
			@Test 
			void testContactServiceUpdateAddress() {
				int contactIndex = 0;
				//Create a contact
				ContactService.createContact("4","John", "Doe", "1234567891", "123 Road");
				//Find contact index
				for(int i = 0; i < ContactService.contacts.size(); i++) {
					if(ContactService.contacts.get(i).getContactID().equals("4")) {
						contactIndex = i;
					}
				}
				//Update address at index
				ContactService.updateAddress("4", "456 Circle Drive");
				//Check to validate object values match expected values
				assertTrue(ContactService.contacts.get(contactIndex).getAddress().equals("456 Circle Drive"));
			}
			
			//Test for duplicate ID rejection
			@Test
			void testContactServiceDuplicateID() {
				//Create contact
				ContactService.createContact("1234","John", "Doe", "1234567891", "123 Road");
				//Create duplicate contact and validate error throw
				Assertions.assertThrows(IllegalArgumentException.class, () -> {ContactService.createContact("1234","John", "Doe", "1234567891", "123 Road");
				});
			}
		}
	
		
