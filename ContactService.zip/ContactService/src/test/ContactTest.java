package test;
//Import required packages
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import contact.Contact;

class ContactTest{
	
	//Test the creation of a contact object
	@Test
	void testContact() {
		//Create contact object
		Contact contact = new Contact("1234", "John", "Doe", "1234567891", "123 Road");
		//Check to validate object values match expected values
		assertTrue(contact.getContactID().equals("1234"));
		assertTrue(contact.getFirstName().equals("John"));
		assertTrue(contact.getLastName().equals("Doe"));
		assertTrue(contact.getPhone().equals("1234567891"));
		assertTrue(contact.getAddress().equals("123 Road"));
	}
	
	//Test error response from long contactID
	@Test
	void testContactIDTooLong() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "John", "Doe", "1234567891", "123 Road");
		});
	}
	
	//Test error response from null contactID
	@Test
	void testContactIDIsNull() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "John", "Doe", "1234567891", "123 Road");
		});
	}
	
	//Test error response from long first name
	@Test
	void testFirstNameTooLong() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234", "Johnjohnjohn", "Doe", "1234567891", "123 Road");
		});
	}
	
	//Test error response from null first name
	@Test
	void testFirstNameIsNull() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", null, "Doe", "1234567891", "123 Road");
		});
	}
	
	//Test error response from long last name
	@Test
	void testLastNameTooLong() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234", "John", "Doedoedoedoe", "1234567891", "123 Road");
		});
	}
	
	//Test error response from null last name
	@Test
	void testLastNameIsNull() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "John", null, "1234567891", "123 Road");
		});
	}
	
	//Test error response from long phone number
	@Test
	void testPhoneTooLong() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234", "John", "Doe", "12345678910", "123 Road");
		});
	}
	
	//Test error response from short phone number
	@Test
	void testPhoneTooShort() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234", "John", "Doe", "1", "123 Road");
		});
	}
	
	//Test error response from null phone number
	@Test
	void testPhoneIsNull() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "John", "Doe", null, "123 Road");
		});
	}
	
	//Test error response from long address
	@Test
	void testAddressTooLong() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234", "John", "Doe", "1234567891", "1234567891011121314151617181920 Road");
		});
	}
	
	//Test error response from null address
	@Test
	void testAddressIsNull() {
		//Check for error throw
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "John", "Doe", "1234567891", null);
		});
	}
}