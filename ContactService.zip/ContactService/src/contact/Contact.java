package contact;

public class Contact{
	//Declare private variables
	final private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	//Constructor to create contact object
	public Contact(String contactID, String firstName, String lastName, String phone, String address) {
		if(contactID == null || contactID.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		if(firstName == null || firstName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid First Name");
		}
		if(lastName == null || lastName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Last Name");
		}
		if(phone == null || phone.length() != 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		if(address == null || address.length() > 30) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Address");
		}
		
		//If all entries are valid, creates object
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	//Method to return contactID
	public String getContactID() {
		return contactID;
	}
	
	//Method to return first name
	public String getFirstName() {
		return firstName;
	}
	
	//Method to return last name
	public String getLastName() {
		return lastName;
	}
	
	//Method to return phone number
	public String getPhone() {
		return phone;
	}
	
	//Method to return address
	public String getAddress() {
		return address;
	}
	
	
	//Method to set first name
	public void setFirstName(String firstName) {
		if(firstName == null || firstName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid First Name");
		}
		//Set first name to new value
		this.firstName = firstName;
	}
	
	//Method to set last name
	public void setLastName(String lastName) {
		if(lastName == null || lastName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Last Name");
		}
		//Set last name to new value
		this.lastName = lastName;
	}
	
	//Method to set phone number
	public void setPhone(String phone) {
		if(phone == null || phone.length() != 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		//Set number to new number
		this.phone = phone;
	}
	
	//Method to set address
	public void setAddress(String address) {
		if(address == null || address.length() > 30) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Address");
		}
		//Set address to new address
		this.address = address;
	}
}