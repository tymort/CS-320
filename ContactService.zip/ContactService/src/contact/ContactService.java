package contact;
//Import required packages
import java.util.ArrayList;

public class ContactService{
	//Declare public variables
	public String firstName;
	public String lastName;
	public String phone;
	public String address;
	
	//Create an ArrayList for contact objects
	public static ArrayList<Contact> contacts = new ArrayList<Contact>(0);
	
	//Create a constructor with no ID
	public static void createContact(String firstName, String lastName, String phone, String address) {
		//Call method to generate an ID
		String contactID = generateContactID();
		//Check if ID is null or too long
		if(contactID == null || contactID.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		//Check if first name is null or too long
		if(firstName == null || firstName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid First Name");
		}
		//Check if last name is null or too long
		if(lastName == null || lastName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Last Name");
		}
		//Check if phone is null or not 10 digits
		if(phone == null || phone.length() != 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		//Check if address is null or too long
		if(address == null || address.length() > 30) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Address");
		}
		//Check for duplicate contact ID
		for (int i=0; i < contacts.size(); i++) {
			if(contactID.equals(contacts.get(i).getContactID())) {
				//Throw error if ID already exists
				throw new IllegalArgumentException("ContactID must be unique");
			}
		}
		//Create contact object if all inputs are valid
		Contact contact = new Contact(contactID, firstName, lastName, phone, address);
		//Add object to ArrayList
		contacts.add(contact);
	}
	
	//Create a constructor with ID
	public static void createContact(String contactID, String firstName, String lastName, String phone, String address) {
		//Check if ID is null or too long
		if(contactID == null || contactID.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		//Check if first name is null or too long
		if(firstName == null || firstName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid First Name");
		}
		//Check if last name is null or too long
		if(lastName == null || lastName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Last Name");
		}
		//Check if phone is null or not 10 digits
		if(phone == null || phone.length() != 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		//Check if address is null or too long
		if(address == null || address.length() > 30) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Address");
		}
		//Check for duplicate contact ID
		for (int i=0; i < contacts.size(); i++) {
			if(contactID.equals(contacts.get(i).getContactID())) {
				//Throw error if ID already exists
				throw new IllegalArgumentException("ContactID must be unique");
			}
		}
		//Create contact object if all inputs are valid
		Contact contact = new Contact(contactID, firstName, lastName, phone, address);	
		//Add object to ArrayList
		contacts.add(contact);
	}
	
	//Method to generate a new unique ID
	public static String generateContactID() {
		//Declare variables
		String contactID;
		int tempInt;
		//Check if list is empty
		if(contacts.isEmpty()) {
			//Declare starting ID
			contactID = "1000000000";
		}
		else {
			//Find size of ArrayList
			int size = contacts.size();
			//Select index of last element
			contactID = contacts.get(size - 1).getContactID();
		}
		 //Convert last element ID to integer
		 tempInt = Integer.parseInt(contactID);
		 //Add one to make ID unique
		 tempInt += 1;
		
		 //Convert integer to string
		 contactID = Integer.toString(tempInt);
		 //Return new ID
		 return contactID;
	}
	
	//Method to update first name
	public static void updateFirstName(String contactID, String firstName) {
		if(firstName == null || firstName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid First Name");
		}
		//Find specified contact
		for(int i = 0; i < contacts.size(); i++) {
			if(contactID.compareTo(contacts.get(i).getContactID()) == 0) {
				//Change first name
				contacts.get(i).setFirstName(firstName);
			}
		}
	}
	
	//Method to update last name
	public static void updateLastName(String contactID, String lastName) {
		if(lastName == null || lastName.length() > 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Last Name");
		}
		//Find specified contact
		for(int i = 0; i < contacts.size(); i++) {
			if(contactID.compareTo(contacts.get(i).getContactID()) == 0) {
				//Change last name
				contacts.get(i).setLastName(lastName);
			}
		}
	}
	
	//Method to update phone number
	public static void updatePhone(String contactID, String phone) {
		if(phone == null || phone.length() != 10) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		//Find specified contact
		for(int i = 0; i < contacts.size(); i++) {
			if(contactID.compareTo(contacts.get(i).getContactID()) == 0) {
				//Change number
				contacts.get(i).setPhone(phone);
			}
		}
	}
	
	//Method to update address
	public static void updateAddress(String contactID, String address) {
		if(address == null || address.length() > 30) {
			//Throw error if invalid
			throw new IllegalArgumentException("Invalid Address");
		}
		//Find specified contact
		for(int i = 0; i < contacts.size(); i++) {
			if(contactID.compareTo(contacts.get(i).getContactID()) == 0) {
				//Change address
				contacts.get(i).setAddress(address);
			}
		}
	}
	
	//Method to delete contact
	public static void deleteContact(String contactID) {
		//Find specified contact
		for(int i = 0; i < contacts.size(); i++) {
			if(contactID.compareTo(contacts.get(i).getContactID()) == 0) {
				//Delete contact from ArrayList
				contacts.remove(i);
			}
		}
	}
}